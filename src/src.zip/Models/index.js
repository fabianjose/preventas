class model {
	constructor() {
		
	}
	
	create() {
		
	}
	read() {
		
	}
	update() {
		
	}
	delete() {
		
	}
	
}

module.exports = model;